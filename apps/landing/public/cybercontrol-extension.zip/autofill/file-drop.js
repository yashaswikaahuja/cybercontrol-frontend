// Generated from autofill/file-drop.ts — edit autofill/file-drop.ts, then pnpm build.
(function() {
  "use strict";
  var prev = globalThis.__ccFileDrop;
  if (prev && typeof prev.destroy === "function") {
    try {
      prev.destroy();
    } catch (e0) {
    }
  }
  var ROOT_ID = "cc-file-drop-root";
  var CHOOSER_RE = /choose\s*(a\s*)?file|browse(\s*files)?|upload\s*files|upload\s*file|select\s*(a\s*)?file|attach\s*file|drop\s+(content|files|file|image|photo|document|here)|drag\s+(and|&)\s+drop|फ़ाइल चुनें|फाइल चुनें/i;
  var armed = null;
  var boxes = [];
  var observer = null;
  var painting = false;
  function cssEscape(value) {
    var s = String(value || "");
    if (typeof CSS !== "undefined" && CSS.escape) return CSS.escape(s);
    return s.replace(/[^a-zA-Z0-9_\-]/g, "\\$&");
  }
  function matchesAccept(accept, mimeType, filename) {
    var raw = String(accept || "").trim();
    if (!raw || raw === "*" || raw === "*.*") return true;
    var mime = String(mimeType || "").toLowerCase();
    if (mime === "image/jpg") mime = "image/jpeg";
    var name = String(filename || "").toLowerCase();
    var ext = name.lastIndexOf(".") >= 0 ? name.slice(name.lastIndexOf(".")) : "";
    var parts = raw.split(",");
    for (var i = 0; i < parts.length; i++) {
      var p = String(parts[i] || "").trim().toLowerCase();
      if (!p) continue;
      if (p === "*/*" || p === "*") return true;
      if (p.charAt(p.length - 1) === "*" && p.charAt(p.length - 2) === "/") {
        if (mime.indexOf(p.slice(0, p.length - 1)) === 0) return true;
        continue;
      }
      if (p.charAt(0) === ".") {
        if (ext === p) return true;
        if ((p === ".jpg" || p === ".jpeg") && mime === "image/jpeg") return true;
        if (p === ".png" && mime === "image/png") return true;
        if (p === ".webp" && mime === "image/webp") return true;
        if (p === ".gif" && mime === "image/gif") return true;
        if (p === ".pdf" && mime === "application/pdf") return true;
        continue;
      }
      if (p === mime) return true;
      if ((p === "image/jpg" || p === "image/jpeg") && mime === "image/jpeg") return true;
    }
    return false;
  }
  function shadowOf(el) {
    if (!el) return null;
    try {
      if (typeof chrome !== "undefined" && chrome.dom && chrome.dom.openOrClosedShadowRoot) {
        var closed = chrome.dom.openOrClosedShadowRoot(el);
        if (closed) return closed;
      }
    } catch (e0) {
    }
    return el.shadowRoot || null;
  }
  function collectFileInputs(root, out, hops) {
    if (!root || hops > 12 || out.length >= 40) return;
    try {
      var all = root.querySelectorAll('input[type="file"]');
      for (var i = 0; i < all.length && out.length < 40; i++) out.push(all[i]);
    } catch (e1) {
    }
    var nodes;
    try {
      nodes = root.querySelectorAll("*");
    } catch (e2) {
      return;
    }
    var cap = Math.min(nodes.length, 2500);
    for (var n = 0; n < cap && out.length < 40; n++) {
      var sr = shadowOf(nodes[n]);
      if (sr) collectFileInputs(sr, out, hops + 1);
    }
  }
  function listInputs() {
    var found = [];
    collectFileInputs(document, found, 0);
    return found;
  }
  function textOf(el) {
    if (!el) return "";
    try {
      return String(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title") || "").replace(/\s+/g, " ").trim();
    } catch (e0) {
      return "";
    }
  }
  function isChooserText(el) {
    return CHOOSER_RE.test(textOf(el));
  }
  function isHidden(el) {
    if (!el || !el.getBoundingClientRect) return true;
    try {
      var st = window.getComputedStyle(el);
      if (!st || st.display === "none" || st.visibility === "hidden") return true;
      if (parseFloat(st.opacity) === 0) return true;
    } catch (e0) {
    }
    var r = el.getBoundingClientRect();
    return !r || r.width < 4 || r.height < 4;
  }
  function inViewport(r) {
    if (!r) return false;
    var vw = window.innerWidth || 0;
    var vh = window.innerHeight || 0;
    return r.bottom > 8 && r.right > 8 && r.left < vw - 8 && r.top < vh - 8 && r.width >= 12 && r.height >= 10;
  }
  function visibleHost(input) {
    if (!isHidden(input)) return input;
    if (input.id) {
      try {
        var lab = document.querySelector('label[for="' + cssEscape(input.id) + '"]');
        if (lab && !isHidden(lab)) return lab;
      } catch (e0) {
      }
    }
    var wrap = null;
    try {
      wrap = input.closest && input.closest("label");
    } catch (e1) {
      wrap = null;
    }
    if (wrap && wrap !== input && !isHidden(wrap)) return wrap;
    var p = input.parentElement;
    var hops = 0;
    while (p && hops < 8) {
      var kids = [];
      try {
        kids = p.querySelectorAll('button, [role="button"], a, input[type="button"], label');
      } catch (e2) {
        kids = [];
      }
      for (var i = 0; i < kids.length; i++) {
        if (kids[i] !== input && !isHidden(kids[i]) && isChooserText(kids[i])) return kids[i];
      }
      if (p !== document.body && p !== document.documentElement && !isHidden(p)) {
        var pr = p.getBoundingClientRect();
        var vw = window.innerWidth || 1200;
        var vh = window.innerHeight || 800;
        if (pr.width >= 40 && pr.height >= 18 && pr.width < vw * 0.72 && pr.height < vh * 0.55) return p;
      }
      p = p.parentElement;
      hops += 1;
    }
    return input;
  }
  function selectorFor(input, host, idx) {
    if (input && input.id) return "#" + cssEscape(input.id);
    var mark = "ccf" + String(idx);
    if (input) {
      try {
        input.setAttribute("data-cc-file", mark);
      } catch (e0) {
      }
      return 'input[type="file"][data-cc-file="' + mark + '"]';
    }
    if (host) {
      try {
        host.setAttribute("data-cc-file-chooser", mark);
      } catch (e1) {
      }
      return '[data-cc-file-chooser="' + mark + '"]';
    }
    return 'input[type="file"]';
  }
  function listChoosers(used) {
    var found = [];
    var seen = used || /* @__PURE__ */ new Set();
    var q = 'button, [role="button"], a, label, input[type="button"], [data-dropzone], [data-testid*="upload" i], [class*="dropzone" i], [class*="file-upload" i]';
    var nodes = [];
    try {
      nodes = document.querySelectorAll(q);
    } catch (e0) {
      nodes = [];
    }
    for (var i = 0; i < nodes.length && found.length < 16; i++) {
      var el = nodes[i];
      if (seen.has(el) || isHidden(el) || !inViewport(el.getBoundingClientRect())) continue;
      if (isChooserText(el) || /upload|dropzone|file-upload/i.test(String(el.className || "") + String(el.getAttribute("data-testid") || ""))) {
        found.push(el);
        seen.add(el);
      }
    }
    var blocks = [];
    try {
      blocks = document.querySelectorAll("div, section, aside, li");
    } catch (e1) {
      blocks = [];
    }
    var cap = Math.min(blocks.length, 800);
    for (var b = 0; b < cap && found.length < 16; b++) {
      var node = blocks[b];
      if (seen.has(node) || isHidden(node)) continue;
      var r = node.getBoundingClientRect();
      if (!inViewport(r) || r.width < 80 || r.height < 40 || r.width > (window.innerWidth || 1200) * 0.7) continue;
      var t = textOf(node);
      if (t.length > 140) continue;
      if (CHOOSER_RE.test(t)) {
        found.push(node);
        seen.add(node);
      }
    }
    return found;
  }
  function rootEl() {
    var el = document.getElementById(ROOT_ID);
    if (el) return el;
    el = document.createElement("div");
    el.id = ROOT_ID;
    el.setAttribute("data-cc-file-drop", "1");
    el.setAttribute("popover", "manual");
    el.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:2147483646",
      "pointer-events:none",
      "font-family:system-ui,sans-serif",
      "margin:0",
      "padding:0",
      "border:0",
      "background:transparent",
      "overflow:visible"
    ].join(";");
    var host = document.documentElement || document.body;
    var openDlg = null;
    try {
      openDlg = document.querySelector("dialog[open]");
    } catch (e0) {
      openDlg = null;
    }
    (openDlg || host).appendChild(el);
    try {
      if (typeof el.showPopover === "function") el.showPopover();
    } catch (e1) {
    }
    return el;
  }
  function clearPaint() {
    var el = document.getElementById(ROOT_ID);
    if (el) {
      try {
        if (typeof el.hidePopover === "function") el.hidePopover();
      } catch (e0) {
      }
      if (el.parentNode) el.parentNode.removeChild(el);
    }
    boxes = [];
  }
  function addBox(root, host, selector) {
    var r = host && host.getBoundingClientRect ? host.getBoundingClientRect() : null;
    if (!inViewport(r)) return;
    var vw = window.innerWidth || 1200;
    var vh = window.innerHeight || 800;
    var width = Math.min(Math.max(28, r.width + 8), Math.min(520, vw - 12));
    var height = Math.min(Math.max(22, r.height + 8), Math.min(240, vh - 12));
    var left = Math.max(4, r.left - 4);
    var top = Math.max(4, r.top - 4);
    if (left + width > vw - 4) left = Math.max(4, vw - width - 4);
    if (top + height > vh - 4) top = Math.max(4, vh - height - 4);
    var box = document.createElement("div");
    box.setAttribute("data-cc-drop-box", "1");
    box.style.cssText = [
      "position:fixed",
      "left:" + left + "px",
      "top:" + top + "px",
      "width:" + width + "px",
      "height:" + height + "px",
      "border:2px dashed #f59e0b",
      "background:rgba(245,158,11,0.18)",
      "border-radius:10px",
      "pointer-events:auto",
      "box-sizing:border-box"
    ].join(";");
    box.dataset.selector = selector;
    root.appendChild(box);
    boxes.push(box);
  }
  function paint() {
    if (painting) return;
    painting = true;
    if (observer) try {
      observer.disconnect();
    } catch (e0) {
    }
    try {
      clearPaint();
      if (!armed) return;
      var inputs = listInputs();
      var usable = [];
      var usedHosts = /* @__PURE__ */ new Set();
      for (var i = 0; i < inputs.length; i++) {
        var input = inputs[i];
        if (input.disabled) continue;
        var accept = input.accept || input.getAttribute && input.getAttribute("accept") || "";
        if (accept && !matchesAccept(accept, armed.mimeType, armed.fileName)) continue;
        var host = visibleHost(input);
        usable.push({ input, host });
        if (host) usedHosts.add(host);
      }
      var choosers = listChoosers(usedHosts);
      var root = rootEl();
      var banner = document.createElement("div");
      banner.style.cssText = [
        "position:fixed",
        "left:50%",
        "top:12px",
        "transform:translateX(-50%)",
        "pointer-events:none",
        "z-index:2147483647",
        "background:#121a2b",
        "color:#e8eefc",
        "border:1px solid #f59e0b",
        "border-radius:999px",
        "padding:8px 14px",
        "font-size:12px",
        "font-weight:650",
        "box-shadow:0 10px 30px rgba(0,0,0,.28)",
        "max-width:90%",
        "white-space:nowrap",
        "overflow:hidden",
        "text-overflow:ellipsis"
      ].join(";");
      var total = usable.length + choosers.length;
      banner.textContent = total ? "Drop " + String(armed.fileName || "file") + " on Choose File / Upload" : "No Choose File or Upload control on this page \u2014 scroll or open the upload panel";
      root.appendChild(banner);
      var idx = 0;
      for (var u = 0; u < usable.length; u++) {
        addBox(root, usable[u].host || usable[u].input, selectorFor(usable[u].input, usable[u].host, idx));
        idx += 1;
      }
      for (var c = 0; c < choosers.length; c++) {
        addBox(root, choosers[c], selectorFor(null, choosers[c], idx));
        idx += 1;
      }
    } finally {
      painting = false;
      if (armed) watch();
    }
  }
  function watch() {
    if (observer) {
      try {
        observer.observe(document.documentElement || document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["style", "class", "hidden", "open"] });
      } catch (e0) {
      }
      return;
    }
    var timer = null;
    observer = new MutationObserver(function() {
      if (!armed || painting) return;
      if (timer) return;
      timer = setTimeout(function() {
        timer = null;
        paint();
      }, 120);
    });
    try {
      observer.observe(document.documentElement || document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["style", "class", "hidden", "open"] });
    } catch (e1) {
    }
  }
  function unwatch() {
    if (observer) {
      try {
        observer.disconnect();
      } catch (e0) {
      }
      observer = null;
    }
  }
  function hitBox(x, y) {
    for (var i = 0; i < boxes.length; i++) {
      var r = boxes[i].getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return boxes[i];
    }
    return null;
  }
  function place(selector, fileId) {
    if (!selector) return;
    try {
      chrome.runtime.sendMessage({
        type: "cc_file_drop",
        selector,
        fileId: fileId || armed && armed.fileId || "",
        fileName: armed && armed.fileName || "",
        mimeType: armed && armed.mimeType || ""
      });
    } catch (e3) {
    }
  }
  function onDragOver(e) {
    if (!armed) return;
    e.preventDefault();
    try {
      e.dataTransfer.dropEffect = "copy";
    } catch (e4) {
    }
  }
  function onDrop(e) {
    if (!armed) return;
    e.preventDefault();
    e.stopPropagation();
    var fileId = "";
    try {
      fileId = e.dataTransfer.getData("text/plain") || "";
    } catch (e5) {
      fileId = "";
    }
    var box = hitBox(e.clientX, e.clientY);
    if (!box && e.target && e.target.dataset && e.target.dataset.selector) box = e.target;
    if (box && box.dataset && box.dataset.selector) place(box.dataset.selector, fileId);
  }
  function onClick(e) {
    if (!armed) return;
    var t = e.target;
    if (!t || !t.dataset || t.dataset.ccDropBox !== "1") return;
    e.preventDefault();
    e.stopPropagation();
    place(t.dataset.selector, armed.fileId);
  }
  function onKey(e) {
    if (!armed) return;
    if (e.key === "Escape") disarm();
  }
  function bind() {
    document.addEventListener("dragover", onDragOver, true);
    document.addEventListener("drop", onDrop, true);
    document.addEventListener("click", onClick, true);
    document.addEventListener("keydown", onKey, true);
    window.addEventListener("resize", paint);
    window.addEventListener("scroll", paint, true);
  }
  function unbind() {
    document.removeEventListener("dragover", onDragOver, true);
    document.removeEventListener("drop", onDrop, true);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("keydown", onKey, true);
    window.removeEventListener("resize", paint);
    window.removeEventListener("scroll", paint, true);
    unwatch();
  }
  function arm(spec) {
    armed = {
      fileId: spec && spec.fileId ? String(spec.fileId) : "",
      fileName: spec && spec.fileName ? String(spec.fileName) : "file",
      mimeType: spec && spec.mimeType ? String(spec.mimeType).toLowerCase() : ""
    };
    paint();
    if (spec && spec.autoPlace && boxes.length === 1) {
      place(boxes[0].dataset.selector, armed.fileId);
    }
  }
  function disarm() {
    armed = null;
    unwatch();
    clearPaint();
  }
  function destroy() {
    disarm();
    unbind();
  }
  bind();
  globalThis.__ccFileDrop = { arm, disarm, destroy };
})();
