// Generated from popup.ts — edit popup.ts, then pnpm build.
var _a, _b;
const VERSION = chrome.runtime.getManifest().version;
let allProfiles = [];
let selectedProfile = null;
let allowLegacyClientFill = false;
let _extBuildInfo = null;
let _lastFillTabId = null;
let _lastFillHost = null;
const profilesEl = document.getElementById("profiles");
const searchEl = document.getElementById("search");
const fillBtn = document.getElementById("fill-btn");
const modeSelect = document.getElementById("mode-select");
const agentBtn = document.getElementById("agent-btn");
const agentPanel = document.getElementById("agent-panel");
const agentActionsEl = document.getElementById("agent-actions");
const agentExecuteBtn = document.getElementById("agent-execute");
const agentCancelBtn = document.getElementById("agent-cancel");
const statusEl = document.getElementById("status");
const connDot = document.getElementById("conn-dot");
const connText = document.getElementById("conn-text");
const progressEl = document.getElementById("progress");
const progressText = document.getElementById("progress-text");
const progressInner = document.getElementById("progress-inner");
const resultsEl = document.getElementById("results");
const versionEl = document.getElementById("ver");
const searchClear = document.getElementById("search-clear");
const listCountEl = document.getElementById("list-count");
const listHintEl = document.getElementById("list-hint");
const fillHintEl = document.getElementById("fill-hint");
const detailBtn = document.getElementById("detail-btn");
const customerPaneEl = document.getElementById("customer-pane");
const paneNameEl = document.getElementById("pane-name");
const paneSubEl = document.getElementById("pane-sub");
const paneBadgeEl = document.getElementById("pane-badge");
const paneBackBtn = document.getElementById("pane-back");
const paneHubBtn = document.getElementById("pane-hub");
const tabDetailBtn = document.getElementById("tab-detail");
const tabFilesBtn = document.getElementById("tab-files");
const detailBodyEl = document.getElementById("detail-body");
const filesBtn = document.getElementById("files-btn");
const filesBodyEl = document.getElementById("files-body");
const placeFilesCta = document.getElementById("place-files-cta");
const hubHeadBtn = document.getElementById("hub-head");
const FILL_BTN_LABEL = "Fill this form";
let _detailOpenId = null;
let _filesOpenId = null;
const _profileCache = /* @__PURE__ */ new Map();
const _filesCache = /* @__PURE__ */ new Map();
const _thumbUrls = /* @__PURE__ */ new Map();
let _filesLoadGen = 0;
let _armedFileId = null;
let _thumbObserver = null;
const _thumbQueued = /* @__PURE__ */ new Set();
let _thumbInflight = 0;
const _thumbWait = [];
let _pdfjsMod = null;
const THUMB_CONCURRENCY = 3;
const THUMB_MAX_PX = 160;
const FILE_TAGS = ["Aadhaar", "PAN", "Passport", "Voter ID", "Driving License", "Ration Card", "Ayushman", "10th Marksheet", "12th Marksheet", "Graduation", "Post-Grad", "Admit Card", "Certificate", "Bank"];
const FILE_MIME = {
  "image/jpeg": "image",
  "image/png": "image",
  "image/webp": "image",
  "image/gif": "image",
  "application/pdf": "pdf"
};
let _canFillPage = false;
let _completenessResolve = null;
versionEl.textContent = "v" + VERSION;
const HUB_FALLBACK = "https://app.cybercontrol.fun";
const HUB_APP_PATH = "/app";
const THEME_KEY = "cc-theme";
function hubOrigin(backendUrl) {
  if (!backendUrl) return HUB_FALLBACK;
  const raw = String(backendUrl);
  if (/localhost:3000|127\.0\.0\.1:3000/.test(raw)) return "http://localhost:5173";
  try {
    const u = new URL(raw);
    if (u.hostname.startsWith("api.")) u.hostname = "app." + u.hostname.slice(4);
    return u.origin;
  } catch (e) {
    return HUB_FALLBACK;
  }
}
function resolveThemePref(pref) {
  if (pref === "light" || pref === "dark") return pref;
  try {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  } catch (e) {
    return "light";
  }
}
function applyPopupTheme(pref) {
  const resolved = resolveThemePref(pref || "system");
  document.documentElement.dataset.theme = resolved;
  document.documentElement.style.colorScheme = resolved;
  return resolved;
}
async function readAndApplyPopupTheme() {
  try {
    const data = await chrome.storage.local.get(THEME_KEY);
    applyPopupTheme(data[THEME_KEY]);
  } catch (e) {
    applyPopupTheme("system");
  }
}
async function initPopupTheme() {
  await readAndApplyPopupTheme();
  try {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = async () => {
      const data = await chrome.storage.local.get(THEME_KEY);
      if ((data[THEME_KEY] || "system") === "system") applyPopupTheme("system");
    };
    if (typeof mq.addEventListener === "function") mq.addEventListener("change", onChange);
    else if (typeof mq.addListener === "function") mq.addListener(onChange);
  } catch (e) {
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") void readAndApplyPopupTheme();
  });
  window.addEventListener("focus", () => {
    void readAndApplyPopupTheme();
  });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[THEME_KEY]) return;
  applyPopupTheme(changes[THEME_KEY].newValue);
});
function escapeHtml(value) {
  return String(value != null ? value : "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function initialsFor(name) {
  return String(name || "?").split(/\s+/).filter(Boolean).map((w) => w[0]).join("").slice(0, 2).toUpperCase() || "?";
}
function isFillableFormUrl(url) {
  if (!url) return false;
  if (/^(chrome|edge|about|chrome-extension|devtools|file):/i.test(url)) return false;
  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    return false;
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
  const host = parsed.hostname.replace(/^www\./, "");
  if (host === "app.cybercontrol.fun" || host === "cybercontrol.fun") return false;
  if (host === "localhost" || host === "127.0.0.1") return false;
  return true;
}
function hideCompletenessWarn(cancelled = true) {
  const warn = document.getElementById("completeness-warn");
  if (warn) {
    warn.style.display = "none";
    warn.innerHTML = "";
  }
  if (_completenessResolve) {
    const resolve = _completenessResolve;
    _completenessResolve = null;
    resolve(cancelled);
  }
}
function syncPaneTabs() {
  const onFiles = !!_filesOpenId;
  const onDetail = !!_detailOpenId;
  if (tabDetailBtn) {
    tabDetailBtn.classList.toggle("on", onDetail);
    tabDetailBtn.setAttribute("aria-selected", onDetail ? "true" : "false");
  }
  if (tabFilesBtn) {
    tabFilesBtn.classList.toggle("on", onFiles);
    tabFilesBtn.setAttribute("aria-selected", onFiles ? "true" : "false");
  }
}
function paintPaneHeader(profile, badgeText, badgeCls) {
  const name = (profile == null ? void 0 : profile.name) || "Customer";
  const phone = getPhone(profile || {});
  if (paneNameEl) paneNameEl.textContent = name;
  if (paneSubEl) paneSubEl.textContent = phone || "No phone on file";
  if (paneBadgeEl) {
    paneBadgeEl.className = "profile-badge " + (badgeCls || "");
    paneBadgeEl.textContent = badgeText || "";
  }
}
function closeCustomerPane() {
  closeProfileFiles();
  closeProfileDetail();
}
function updateFillHint() {
  if (!fillHintEl || !fillBtn) return;
  const canFill = !!(selectedProfile && _canFillPage);
  document.body.classList.toggle("can-fill", canFill);
  document.body.classList.toggle("has-customer", !!selectedProfile);
  fillBtn.disabled = !canFill;
  if (detailBtn) detailBtn.disabled = !selectedProfile;
  if (filesBtn) filesBtn.disabled = !selectedProfile;
  if (canFill) {
    const name = selectedProfile.name || "customer";
    fillHintEl.textContent = _filesOpenId ? `Tap a file, then the box on the form` : _detailOpenId ? `Review ${name}` : `Ready to fill for ${name}`;
    fillHintEl.classList.add("ready");
    fillBtn.title = `Fill the open form for ${name}`;
    if (detailBtn) detailBtn.title = `View details for ${name}`;
    if (filesBtn) filesBtn.title = `Place files for ${name}`;
  } else if (selectedProfile) {
    const name = selectedProfile.name || "customer";
    fillHintEl.textContent = _filesOpenId ? `Open a form page to place files for ${name}` : _detailOpenId ? `Review ${name}` : `Open a form page to fill for ${name}`;
    fillHintEl.classList.remove("ready");
    fillBtn.title = "Open a form page first";
    if (detailBtn) detailBtn.title = `View details for ${name}`;
    if (filesBtn) filesBtn.title = `Place files for ${name}`;
  } else {
    fillHintEl.textContent = "Search and tap a customer";
    fillHintEl.classList.remove("ready");
    fillBtn.title = "Select a customer first";
    if (detailBtn) detailBtn.title = "View customer details";
    if (filesBtn) filesBtn.title = "Place photos and PDFs";
  }
}
function updateSearchClear() {
  if (!searchClear || !searchEl) return;
  searchClear.classList.toggle("visible", !!String(searchEl.value || "").trim());
}
function clearSelection() {
  hideCompletenessWarn();
  closeCustomerPane();
  selectedProfile = null;
  fillBtn.disabled = true;
  applyAgentVisibility();
  chrome.storage.session.remove("_cc_selected").catch(() => {
  });
  updateFillHint();
  renderProfiles((searchEl == null ? void 0 : searchEl.value) || "");
}
function clearSearch() {
  if (!searchEl) return;
  searchEl.value = "";
  focusIdx = -1;
  updateSearchClear();
  renderProfiles("");
  searchEl.focus();
}
async function openHub(path) {
  const data = await chrome.storage.local.get("backendUrl");
  const origin = hubOrigin(data.backendUrl);
  const suffix = !path || path === "/" ? HUB_APP_PATH : path.startsWith("/") ? path : "/" + path;
  const url = origin + suffix;
  const tabs = await chrome.tabs.query({});
  const existing = tabs.find((t) => {
    var _a2;
    return (_a2 = t.url) == null ? void 0 : _a2.startsWith(origin);
  });
  if (existing) {
    chrome.tabs.update(existing.id, { active: true, url });
    chrome.windows.update(existing.windowId, { focused: true });
  } else {
    chrome.tabs.create({ url });
  }
}
function setLocked(locked) {
  document.body.classList.toggle("is-locked", !!locked);
  if (locked) {
    hideCompletenessWarn();
    closeProfileFiles();
    closeProfileDetail();
    revokeFileThumbs();
  }
}
function showLoginEmpty(title, detail) {
  setLocked(true);
  profilesEl.innerHTML = `<div class="empty"><div class="empty-title">${title}</div><div>${detail}</div><button type="button" class="primary" id="open-login-btn">Open CyberControl Hub</button></div>`;
  const btn = document.getElementById("open-login-btn");
  if (btn) btn.onclick = () => openHub(HUB_APP_PATH);
}
function shortSha(s) {
  if (!s || s === "development") return s || "dev";
  return String(s).slice(0, 7);
}
function applyAgentVisibility() {
  if (!agentBtn) return;
  if (allowLegacyClientFill) {
    agentBtn.style.display = "";
    agentBtn.title = "AI Agent (legacy \u2014 owner opt-in)";
    agentBtn.disabled = !selectedProfile;
  } else {
    agentBtn.style.display = "none";
    agentBtn.disabled = true;
    agentBtn.title = "Legacy Agent disabled (Phase 0). Use Fill this form.";
    if (agentPanel) agentPanel.style.display = "none";
  }
}
async function refreshLegacyFillGate() {
  allowLegacyClientFill = false;
  applyAgentVisibility();
}
function renderVersionLine(extCommit, svcCommit) {
  const extShort = shortSha(extCommit || "development");
  let text = `v${VERSION} @ ${extShort}`;
  let title = `Extension ${VERSION}, build ${extCommit || "development"}`;
  if (_extBuildInfo == null ? void 0 : _extBuildInfo.built_at) title += `, ${_extBuildInfo.built_at}`;
  if (svcCommit) {
    const svcShort = shortSha(svcCommit);
    text += ` \xB7 svc ${svcShort}`;
    title += ` | extension-service ${svcCommit}`;
    const bothReal = extCommit && svcCommit && extCommit !== "development" && svcCommit !== "development";
    if (bothReal && String(extCommit).slice(0, 7) !== String(svcCommit).slice(0, 7)) {
      text += " \u26A0 mismatch";
      title += " \u2014 DEPLOY LOCK: extension zip commit should match extension-service BUILD_SHA. See deploy/docs/EXTENSION-DEPLOY-LOCK.md";
      versionEl.style.color = "hsl(0 65% 42%)";
    } else {
      versionEl.style.color = "";
    }
  }
  versionEl.textContent = text;
  versionEl.title = title;
}
async function loadDeployProvenance() {
  try {
    const response = await fetch(chrome.runtime.getURL("build-info.json"));
    _extBuildInfo = response.ok ? await response.json() : null;
  } catch (e) {
    _extBuildInfo = null;
  }
  const extCommit = (_extBuildInfo == null ? void 0 : _extBuildInfo.commit) || "development";
  renderVersionLine(extCommit, null);
  try {
    const { backendUrl } = await chrome.storage.local.get("backendUrl");
    if (!backendUrl) return;
    const healthUrl = String(backendUrl).replace(/\/?$/, "") + "/extension/health";
    const hr = await fetch(healthUrl);
    if (!hr.ok) return;
    const body = await hr.json();
    if (body == null ? void 0 : body.commit) renderVersionLine(extCommit, body.commit);
  } catch (e) {
  }
}
refreshLegacyFillGate();
loadDeployProvenance();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.allowLegacyClientFill) refreshLegacyFillGate();
});
async function getActivePageTab() {
  const isPageUrl = (u) => !!u && !u.startsWith("chrome-extension://") && !u.startsWith("chrome://") && !u.startsWith("edge://") && !u.startsWith("about:") && !u.startsWith("devtools:");
  let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let tab = tabs.find((t) => isPageUrl(t.url)) || tabs[0];
  if (!isPageUrl(tab == null ? void 0 : tab.url)) {
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = tabs.find((t) => isPageUrl(t.url)) || tabs[0];
  }
  if (!isPageUrl(tab == null ? void 0 : tab.url)) {
    const allTabs = await chrome.tabs.query({ lastFocusedWindow: true });
    tab = allTabs.find((t) => t.active && isPageUrl(t.url)) || allTabs.find((t) => isPageUrl(t.url)) || tab;
  }
  if (!isPageUrl(tab == null ? void 0 : tab.url)) {
    const any = await chrome.tabs.query({});
    tab = any.find((t) => t.active && isPageUrl(t.url)) || any.find((t) => isPageUrl(t.url)) || tab;
  }
  return tab || null;
}
const CC = {
  warning: "hsl(35 92% 38%)",
  danger: "hsl(0 65% 45%)",
  success: "hsl(158 60% 28%)",
  info: "hsl(22 90% 42%)",
  muted: "hsl(30 10% 40%)"
};
function showStatus(msg, color) {
  statusEl.textContent = msg;
  statusEl.style.color = color || CC.warning;
  statusEl.style.display = "block";
  if (color !== CC.danger) {
    setTimeout(() => {
      statusEl.style.display = "none";
    }, 4e3);
  }
}
statusEl == null ? void 0 : statusEl.addEventListener("click", () => {
  statusEl.style.display = "none";
});
function clearStaleFillSummary(activeTabId, activeHost) {
  if (!_lastFillTabId && !_lastFillHost) return;
  const sameTab = activeTabId && activeTabId === _lastFillTabId;
  const sameHost = activeHost && _lastFillHost && activeHost === _lastFillHost;
  if (sameTab && sameHost) return;
  _lastFillTabId = null;
  _lastFillHost = null;
  window._lastFilledRecords = [];
  if (resultsEl) resultsEl.style.display = "none";
  if (typeof undoBtn !== "undefined" && undoBtn) undoBtn.style.display = "none";
  const detailEl = document.getElementById("results-detail");
  if (detailEl) {
    detailEl.innerHTML = "";
    detailEl.style.display = "none";
  }
  const filledEl = document.getElementById("results-filled");
  if (filledEl) {
    filledEl.innerHTML = "";
    filledEl.style.display = "none";
  }
}
async function syncActivePage() {
  try {
    const tab = await getActivePageTab();
    let host = null;
    try {
      if (tab == null ? void 0 : tab.url) host = new URL(tab.url).hostname.replace(/^www\./, "");
    } catch (e) {
    }
    const fillable = isFillableFormUrl(tab == null ? void 0 : tab.url);
    if (_canFillPage && !fillable) hideCompletenessWarn();
    _canFillPage = fillable;
    updateFillHint();
    clearStaleFillSummary((tab == null ? void 0 : tab.id) || null, host);
  } catch (e) {
  }
}
if ((_a = chrome.tabs) == null ? void 0 : _a.onActivated) {
  chrome.tabs.onActivated.addListener(() => {
    syncActivePage();
  });
}
if ((_b = chrome.tabs) == null ? void 0 : _b.onUpdated) {
  chrome.tabs.onUpdated.addListener((tabId, info) => {
    if (info.status === "complete" || info.url) {
      chrome.tabs.query({ active: true, currentWindow: true }).then(([active]) => {
        if ((active == null ? void 0 : active.id) === tabId) syncActivePage();
      }).catch(() => {
      });
    }
  });
}
function showProgress(text) {
  resultsEl.style.display = "none";
  progressEl.style.display = "block";
  progressText.textContent = text;
  progressInner.style.width = "30%";
}
function updateProgress(text, pct) {
  progressText.textContent = text;
  progressInner.style.width = pct + "%";
}
function hideProgress() {
  progressEl.style.display = "none";
}
function showResults(filled, skipped, failed, records) {
  hideProgress();
  const total = filled + skipped + failed || 1;
  document.getElementById("r-filled").textContent = filled;
  document.getElementById("r-skipped").textContent = skipped;
  document.getElementById("r-failed").textContent = failed;
  const bar = document.getElementById("results-bar");
  bar.innerHTML = `<div class="filled" style="width:${filled / total * 100}%"></div><div class="skipped" style="width:${skipped / total * 100}%"></div><div class="failed" style="width:${failed / total * 100}%"></div>`;
  const detailEl = document.getElementById("results-detail");
  const issues = (records || []).filter((r) => r.result && r.result !== "filled");
  if (issues.length) {
    detailEl.innerHTML = issues.slice(0, 8).map((r) => {
      var _a2;
      const color = r.result === "unmapped" ? "hsl(35 92% 38%)" : "hsl(0 65% 45%)";
      const label = r.label || ((_a2 = r.selector) == null ? void 0 : _a2.replace(/[#.\[\]]/g, "").slice(0, 20)) || "?";
      return `<span class="field-tag" style="border-color:${color};color:${color}">${label}</span>`;
    }).join("") + (issues.length > 8 ? `<span class="field-tag" style="color:hsl(30 10% 40%)">+${issues.length - 8} more</span>` : "");
    detailEl.style.display = "flex";
  } else {
    detailEl.style.display = "none";
  }
  const filledEl = document.getElementById("results-filled");
  if (filledEl) {
    const fr = window._lastFilledRecords || [];
    if (fr.length) {
      filledEl.innerHTML = `<div class="filled-toggle" id="filled-toggle">\u25B8 See what was filled (${fr.length})</div>
        <div id="filled-list" style="display:none"></div>`;
      const listEl = filledEl.querySelector("#filled-list");
      listEl.innerHTML = fr.map((r) => {
        const label = (r.label || r.selector || "").toString().replace(/[#.\[\]]/g, "").slice(0, 28);
        const val = (r.value != null ? String(r.value) : "").slice(0, 30);
        return `<div class="filled-row"><span class="fl-label">${label}</span><span class="fl-val">${val}</span><span class="fl-check">\u2713</span></div>`;
      }).join("");
      const toggle = filledEl.querySelector("#filled-toggle");
      toggle.onclick = () => {
        const open = listEl.style.display === "block";
        listEl.style.display = open ? "none" : "block";
        toggle.textContent = (open ? "\u25B8" : "\u25BE") + ` See what was filled (${fr.length})`;
      };
      filledEl.style.display = "block";
    } else {
      filledEl.style.display = "none";
    }
  }
  const cpLink = document.getElementById("complete-profile-link");
  if (skipped > 0 || failed > 0) {
    cpLink.style.display = "block";
    cpLink.onclick = async () => {
      const data = await chrome.storage.local.get("backendUrl");
      const phone = (selectedProfile == null ? void 0 : selectedProfile.phone) || (selectedProfile == null ? void 0 : selectedProfile.primary_contact_phone) || "";
      const url = hubOrigin(data.backendUrl) + "/app/customers/" + encodeURIComponent(phone);
      chrome.tabs.create({ url });
    };
  } else {
    cpLink.style.display = "none";
  }
  if (placeFilesCta) {
    placeFilesCta.style.display = selectedProfile ? "flex" : "none";
    placeFilesCta.onclick = () => {
      if (selectedProfile == null ? void 0 : selectedProfile.id) openProfileFiles(selectedProfile.id);
    };
  }
  resultsEl.style.display = "block";
}
function getPhone(p) {
  return p.phone || p.primary_contact_phone || "";
}
let focusIdx = -1;
let filteredProfiles = [];
let recentIds = [];
async function loadRecents() {
  const data = await chrome.storage.local.get("_cc_recents");
  recentIds = data._cc_recents || [];
}
async function saveRecent(profileId) {
  recentIds = [profileId, ...recentIds.filter((id) => id !== profileId)].slice(0, 5);
  await chrome.storage.local.set({ _cc_recents: recentIds });
}
function badgeHtmlFor(profile) {
  const { percent } = getCompleteness(profile);
  const data = (profile == null ? void 0 : profile.data) || profile || {};
  const hasSignal = REQUIRED_FIELDS.some((key) => {
    const val = data[key];
    const v = val && typeof val === "object" ? val.value : val;
    return !!v;
  }) || percent > 0 && ((profile == null ? void 0 : profile.data) || (profile == null ? void 0 : profile.aadhaar_number) || (profile == null ? void 0 : profile.father_name));
  if (!hasSignal && percent === 0) return "";
  const cls = percent >= 85 ? "ok" : percent >= 50 ? "warn" : "low";
  return `<span class="profile-badge ${cls}" title="Profile ${percent}% ready for common govt fields">${percent}%</span>`;
}
function updateListMeta(query, visibleCount, totalFiltered) {
  if (listCountEl) {
    if (!allProfiles.length) {
      listCountEl.textContent = "";
    } else if (query) {
      listCountEl.textContent = totalFiltered > visibleCount ? `${visibleCount} of ${totalFiltered} matches` : `${totalFiltered} match${totalFiltered === 1 ? "" : "es"}`;
    } else {
      listCountEl.textContent = totalFiltered > visibleCount ? `Showing ${visibleCount} of ${allProfiles.length}` : `${allProfiles.length} customer${allProfiles.length === 1 ? "" : "s"}`;
    }
  }
  if (listHintEl) {
    if (selectedProfile) {
      listHintEl.textContent = "Then Fill, Files, or Profile";
    } else if (totalFiltered > 0) {
      listHintEl.textContent = "Tap a customer";
    } else {
      listHintEl.textContent = "";
    }
  }
}
function renderProfiles(query) {
  const q = (query || "").toLowerCase().trim();
  let list = q ? allProfiles.filter((p) => (p.name || "").toLowerCase().includes(q) || getPhone(p).includes(q)) : allProfiles;
  if (!q && recentIds.length) {
    const recents = recentIds.map((id) => list.find((p) => p.id === id)).filter(Boolean);
    const rest = list.filter((p) => !recentIds.includes(p.id));
    list = [...recents, ...rest];
  }
  filteredProfiles = list;
  if (!filteredProfiles.length) {
    profilesEl.innerHTML = q ? `<div class="empty"><div class="empty-title">No match</div>No customer matches \u201C${escapeHtml(query)}\u201D. Try phone digits or another name.</div>` : `<div class="empty"><div class="empty-title">No customers yet</div>Add customers in CyberControl Hub for this cafe, then come back here.</div>`;
    focusIdx = -1;
    updateListMeta(q, 0, 0);
    return;
  }
  if (filteredProfiles.length === 1 && q) {
    selectedProfile = filteredProfiles[0];
    focusIdx = 0;
    fillBtn.disabled = false;
    applyAgentVisibility();
    updateFillHint();
  }
  const visibleList = filteredProfiles.slice(0, 20);
  const recentCount = !q ? recentIds.filter((id) => allProfiles.some((x) => x.id === id)).length : 0;
  updateListMeta(q, visibleList.length, filteredProfiles.length);
  profilesEl.innerHTML = visibleList.map((p, i) => {
    const initials = escapeHtml(initialsFor(p.name));
    const isSelected = (selectedProfile == null ? void 0 : selectedProfile.id) === p.id;
    const isFocused = i === focusIdx;
    const phone = getPhone(p);
    const name = escapeHtml(p.name || "Unknown");
    const phoneLabel = phone ? `\u{1F4F1} ${escapeHtml(phone)}` : "No phone on file";
    const badge = badgeHtmlFor(p);
    let label = "";
    if (!q && i === 0 && recentCount > 0) label = '<div class="section-label">Recent</div>';
    if (!q && i === recentCount && recentCount > 0) label = '<div class="section-label">All customers</div>';
    return `${label}<div class="profile-item${isSelected ? " selected" : ""}${isFocused ? " focused" : ""}" data-id="${escapeHtml(p.id)}" data-idx="${i}" role="option" aria-selected="${isSelected}">
      <div class="avatar">${initials}</div>
      <div class="profile-body">
        <div class="profile-name-row">
          <div class="profile-name">${name}</div>
          ${badge}
        </div>
        <div class="profile-phone">${phoneLabel}</div>
      </div>
    </div>`;
  }).join("");
  profilesEl.querySelectorAll(".profile-item").forEach((el) => {
    el.addEventListener("click", () => {
      selectProfile(el.dataset.id);
    });
    el.addEventListener("pointerenter", () => {
      const id = el.dataset.id;
      if (id && !profileHasDetailFields(_profileCache.get(id) || allProfiles.find((p) => p.id === id))) {
        void prefetchProfile(id);
      }
    });
  });
  const focused = profilesEl.querySelector(".profile-item.focused") || profilesEl.querySelector(".profile-item.selected");
  if (focused && typeof focused.scrollIntoView === "function") {
    focused.scrollIntoView({ block: "nearest" });
  }
}
function selectProfile(id, opts = {}) {
  hideCompletenessWarn();
  selectedProfile = allProfiles.find((p) => p.id === id) || null;
  fillBtn.disabled = !selectedProfile;
  applyAgentVisibility();
  if (selectedProfile) {
    chrome.storage.session.set({ _cc_selected: id });
    prefetchProfile(id);
  } else {
    chrome.storage.session.remove("_cc_selected").catch(() => {
    });
  }
  updateFillHint();
  if (!opts.skipRender) renderProfiles(searchEl.value);
}
let _prefetchedProfile = null;
let _prefetchInflight = /* @__PURE__ */ new Map();
function rememberProfile(profile) {
  if (!(profile == null ? void 0 : profile.id)) return profile;
  _profileCache.set(profile.id, profile);
  _prefetchedProfile = profile;
  const listed = allProfiles.find((p) => p.id === profile.id);
  if (listed && profile.data) listed.data = profile.data;
  return profile;
}
function profileHasDetailFields(profile) {
  const data = profile == null ? void 0 : profile.data;
  return !!(data && typeof data === "object" && Object.keys(data).length > 0);
}
async function prefetchProfile(id) {
  if (!id) return null;
  const cached = _profileCache.get(id);
  if (profileHasDetailFields(cached)) return cached;
  const listed = allProfiles.find((p) => p.id === id);
  if (profileHasDetailFields(listed)) return rememberProfile(listed);
  if (_prefetchInflight.has(id)) return _prefetchInflight.get(id);
  const pending = (async () => {
    try {
      const data = await chrome.storage.local.get(["backendUrl", "accessToken"]);
      const r = await fetch(data.backendUrl + "/profiles/" + id, {
        headers: { Authorization: "Bearer " + data.accessToken }
      });
      if (r.ok) {
        const full = rememberProfile(await r.json());
        if (_detailOpenId === id && !profileHasDetailFields(cached || listed)) {
          renderProfileDetail(full);
        }
        return full;
      }
    } catch (e) {
    }
    return null;
  })();
  _prefetchInflight.set(id, pending);
  try {
    return await pending;
  } finally {
    _prefetchInflight.delete(id);
  }
}
searchEl.addEventListener("keydown", (e) => {
  var _a2, _b2;
  const max = Math.min(filteredProfiles.length, 20);
  if (e.key === "ArrowDown") {
    e.preventDefault();
    focusIdx = Math.min(focusIdx + 1, max - 1);
    renderProfiles(searchEl.value);
  } else if (e.key === "ArrowUp") {
    e.preventDefault();
    focusIdx = Math.max(focusIdx - 1, 0);
    renderProfiles(searchEl.value);
  } else if (e.key === "Enter") {
    e.preventDefault();
    if (selectedProfile && (focusIdx === -1 || ((_a2 = filteredProfiles[focusIdx]) == null ? void 0 : _a2.id) === selectedProfile.id)) {
      fillBtn.click();
    } else if (focusIdx >= 0 && filteredProfiles[focusIdx]) {
      selectProfile(filteredProfiles[focusIdx].id);
      focusIdx = filteredProfiles.findIndex((p) => p.id === (selectedProfile == null ? void 0 : selectedProfile.id));
    } else if (filteredProfiles.length === 1) {
      selectProfile(filteredProfiles[0].id);
    }
  } else if (e.key === "Escape") {
    e.preventDefault();
    if (_filesOpenId || _detailOpenId) {
      closeCustomerPane();
    } else if (((_b2 = document.getElementById("completeness-warn")) == null ? void 0 : _b2.style.display) === "flex") {
      hideCompletenessWarn();
    } else if (String(searchEl.value || "").trim()) {
      clearSearch();
    } else if (selectedProfile) {
      clearSelection();
    }
  }
});
searchClear == null ? void 0 : searchClear.addEventListener("click", (e) => {
  e.preventDefault();
  clearSearch();
});
function applyWssPresence(wss, fallbackName) {
  if (!connDot || !connText) return;
  const state = wss && wss.state || "disconnected";
  connDot.classList.remove("green", "amber");
  if (state === "connected") {
    connDot.classList.add("green");
    connText.textContent = fallbackName || "Connected";
    connText.title = wss.sessionId ? "Live \xB7 session " + wss.sessionId : "Live connection";
  } else if (state === "connecting" || state === "reconnecting") {
    connDot.classList.add("amber");
    connText.textContent = state === "connecting" ? "Connecting\u2026" : "Reconnecting\u2026";
    connText.title = wss && wss.lastError || state;
  } else if (state === "suspended") {
    connText.textContent = "Server busy";
    connText.title = wss && wss.lastError || "server unavailable";
  } else if (fallbackName) {
    connDot.classList.add("amber");
    connText.textContent = fallbackName;
    connText.title = wss && wss.lastError || "Signed in \u2014 live link reconnecting";
  } else {
    connText.textContent = "Offline";
    connText.title = "Not connected to CyberControl";
  }
}
async function refreshWssPresence(fallbackName) {
  try {
    const st = await chrome.storage.local.get("ccWssState");
    applyWssPresence(st.ccWssState, fallbackName);
    chrome.runtime.sendMessage({ type: "ENSURE_WSS" }, () => {
      void chrome.runtime.lastError;
    });
  } catch (e) {
  }
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.ccWssState) return;
  const name = (connText.textContent || "").trim();
  const keepName = name && !/^(Checking|Connecting|Reconnecting|Connected|Offline|Server busy|Signed out|Session expired|Not connected)/i.test(
    name
  );
  applyWssPresence(changes.ccWssState.newValue, keepName ? name : null);
});
async function init() {
  document.getElementById("ver").textContent = "v" + VERSION;
  await initPopupTheme();
  updateFillHint();
  syncActivePage();
  await loadRecents();
  const data = await chrome.storage.local.get(["accessToken", "backendUrl", "user"]);
  if (!data.accessToken || !data.backendUrl) {
    connText.textContent = "Signed out";
    showLoginEmpty("Sign in required", "Open CyberControl Hub and sign in as the cafe account, then reopen this panel.");
    return;
  }
  let operatorName = null;
  try {
    const r = await fetch(data.backendUrl + "/auth/me", {
      headers: { "Authorization": "Bearer " + data.accessToken }
    });
    if (r.ok) {
      const user = await r.json();
      operatorName = (user.name || user.email || "Operator").split(" ")[0];
      connDot.classList.add("green");
      connText.textContent = operatorName;
      setLocked(false);
    } else {
      connText.textContent = "Session expired";
      showLoginEmpty("Session expired", "Sign in again in CyberControl Hub, then reopen this panel.");
      return;
    }
  } catch (e) {
    connText.textContent = "Offline";
    setLocked(false);
  }
  await refreshWssPresence(operatorName);
  await loadProfilesHttps(data);
  await refreshMcpPrivacy(data);
  setInterval(() => {
    if (document.visibilityState === "visible") void refreshMcpPrivacy();
  }, 5e3);
}
async function refreshMcpPrivacy(credentials) {
  const policyEl = document.getElementById("mcp-policy-state");
  const sessionsEl = document.getElementById("mcp-sessions");
  const requestsEl = document.getElementById("mcp-requests");
  if (!policyEl || !sessionsEl || !requestsEl) return;
  const creds = credentials || await chrome.storage.local.get(["accessToken", "backendUrl"]);
  if (!creds.accessToken || !creds.backendUrl) return;
  const base = String(creds.backendUrl).replace(/\/$/, "");
  const headers = { Authorization: "Bearer " + creds.accessToken };
  try {
    const [policyRes, sessionsRes, requestsRes] = await Promise.all([
      fetch(base + "/privacy/profile-policy", { headers }),
      fetch(base + "/privacy/mcp-sessions", { headers }),
      fetch(base + "/privacy/profile-read-requests", { headers })
    ]);
    if (!policyRes.ok || !sessionsRes.ok || !requestsRes.ok) throw new Error("privacy_controls_unavailable");
    const policy = await policyRes.json();
    const sessionsBody = await sessionsRes.json();
    const requestsBody = await requestsRes.json();
    const enabled = policy.allowMcpProfileRead === true;
    policyEl.innerHTML = enabled ? '<span style="color:hsl(var(--pt-success))">Workspace policy: enabled</span> \xB7 Each client session still needs operator approval.' : '<span style="color:hsl(var(--pt-danger))">Workspace policy: disabled</span> \xB7 Ask a workspace admin to enable it in Hub Settings.';
    const sessions = Array.isArray(sessionsBody.sessions) ? sessionsBody.sessions : [];
    sessionsEl.innerHTML = sessions.length ? sessions.map((session) => {
      const active = session.profileAccessEnabled === true;
      const disabled = !enabled && !active;
      return `<div style="border:1px solid hsl(var(--pt-border));border-radius:8px;padding:8px;display:flex;align-items:center;gap:8px">
        <div style="min-width:0;flex:1">
          <div style="font-size:11px;font-weight:650;color:hsl(var(--pt-ink))">${escapeHtml(session.clientName || "MCP client")}</div>
          <div class="pt-muted" style="font-size:10px">${active ? "Session access enabled" : "Session access disabled"}</div>
        </div>
        <button type="button" data-mcp-session="${escapeHtml(session.sessionId)}" data-enabled="${active ? "false" : "true"}"
          ${disabled ? "disabled" : ""} style="font-size:10px;padding:5px 8px;border-radius:7px;border:1px solid hsl(var(--pt-border));background:${active ? "hsl(var(--pt-secondary))" : "hsl(var(--pt-marigold))"};color:${active ? "hsl(var(--pt-ink))" : "#20170e"}">
          ${active ? "Disable" : "Enable"}
        </button>
      </div>`;
    }).join("") : '<div class="pt-muted" style="font-size:11px">No connected MCP client sessions yet.</div>';
    const requests = Array.isArray(requestsBody.requests) ? requestsBody.requests : [];
    requestsEl.innerHTML = requests.length ? '<div style="font-size:11px;font-weight:700;color:hsl(var(--pt-ink))">Pending customer-data approvals</div>' + requests.map((request) => {
      const fields = Array.isArray(request.fields) ? request.fields : [];
      const categories = Array.isArray(request.dataCategories) ? request.dataCategories : [];
      return `<div style="border:1px solid hsl(var(--pt-warning));border-radius:8px;padding:9px;display:grid;gap:6px">
        <div style="font-size:11px;font-weight:700;color:hsl(var(--pt-ink))">${escapeHtml(request.profileLabel || "Customer")}</div>
        <div class="pt-muted" style="font-size:10px">Client: ${escapeHtml(request.clientName || "MCP client")}</div>
        <div style="font-size:10px;color:hsl(var(--pt-ink-soft));overflow-wrap:anywhere">Fields: ${escapeHtml(fields.join(", "))}</div>
        <div class="pt-muted" style="font-size:10px">Categories: ${escapeHtml(categories.join(", "))}</div>
        <label style="display:flex;gap:6px;align-items:flex-start;font-size:10px;color:hsl(var(--pt-ink-soft))">
          <input type="checkbox" data-mcp-confirm="${escapeHtml(request.id)}" style="margin-top:1px">
          I have informed this customer and they agreed to share these fields with this MCP client for form filling.
        </label>
        <div style="display:flex;gap:6px">
          <button type="button" data-mcp-approve="${escapeHtml(request.id)}" disabled
            style="flex:1;font-size:10px;padding:6px;border-radius:7px;background:hsl(var(--pt-marigold));color:#20170e">Approve for 5 minutes</button>
          <button type="button" data-mcp-reject="${escapeHtml(request.id)}"
            style="font-size:10px;padding:6px;border-radius:7px;border:1px solid hsl(var(--pt-border));color:hsl(var(--pt-ink))">Reject</button>
        </div>
      </div>`;
    }).join("") : "";
    const privacyPanel = document.getElementById("mcp-privacy");
    if (privacyPanel && requests.length) privacyPanel.open = true;
  } catch (error) {
    policyEl.textContent = "Could not load MCP privacy controls. Profile reads remain blocked unless the server confirms permission.";
    sessionsEl.innerHTML = "";
    requestsEl.innerHTML = "";
    console.warn("[CC privacy] controls unavailable", error);
  }
}
async function updateMcpPrivacy(path, body) {
  const creds = await chrome.storage.local.get(["accessToken", "backendUrl"]);
  if (!creds.accessToken || !creds.backendUrl) throw new Error("Sign in required");
  const response = await fetch(String(creds.backendUrl).replace(/\/$/, "") + path, {
    method: "PATCH",
    headers: { Authorization: "Bearer " + creds.accessToken, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Privacy setting update failed");
  return result;
}
const mcpSessionsEl = document.getElementById("mcp-sessions");
if (mcpSessionsEl) mcpSessionsEl.addEventListener("click", async (event) => {
  var _a2, _b2;
  const button = (_b2 = (_a2 = event.target) == null ? void 0 : _a2.closest) == null ? void 0 : _b2.call(_a2, "[data-mcp-session]");
  if (!button) return;
  button.disabled = true;
  try {
    await updateMcpPrivacy("/privacy/mcp-sessions/" + encodeURIComponent(button.dataset.mcpSession) + "/profile-access", {
      enabled: button.dataset.enabled === "true"
    });
    await refreshMcpPrivacy();
  } catch (error) {
    showStatus(error.message || "Could not update MCP session", CC.danger);
    button.disabled = false;
  }
});
const mcpRequestsEl = document.getElementById("mcp-requests");
if (mcpRequestsEl) {
  mcpRequestsEl.addEventListener("change", (event) => {
    var _a2, _b2;
    const checkbox = (_b2 = (_a2 = event.target) == null ? void 0 : _a2.closest) == null ? void 0 : _b2.call(_a2, "[data-mcp-confirm]");
    if (!checkbox) return;
    const approve = mcpRequestsEl.querySelector('[data-mcp-approve="' + CSS.escape(checkbox.dataset.mcpConfirm) + '"]');
    if (approve) approve.disabled = !checkbox.checked;
  });
  mcpRequestsEl.addEventListener("click", async (event) => {
    var _a2, _b2, _c, _d;
    const approve = (_b2 = (_a2 = event.target) == null ? void 0 : _a2.closest) == null ? void 0 : _b2.call(_a2, "[data-mcp-approve]");
    const reject = (_d = (_c = event.target) == null ? void 0 : _c.closest) == null ? void 0 : _d.call(_c, "[data-mcp-reject]");
    const button = approve || reject;
    if (!button) return;
    const requestId = button.dataset.mcpApprove || button.dataset.mcpReject;
    const confirm = mcpRequestsEl.querySelector('[data-mcp-confirm="' + CSS.escape(requestId) + '"]');
    if (approve && !(confirm == null ? void 0 : confirm.checked)) return;
    button.disabled = true;
    try {
      const creds = await chrome.storage.local.get(["accessToken", "backendUrl"]);
      const response = await fetch(String(creds.backendUrl).replace(/\/$/, "") + "/privacy/profile-read-requests/" + encodeURIComponent(requestId) + "/decision", {
        method: "POST",
        headers: { Authorization: "Bearer " + creds.accessToken, "Content-Type": "application/json" },
        body: JSON.stringify({ approve: !!approve, customerInformed: !!(approve && (confirm == null ? void 0 : confirm.checked)) })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Approval decision failed");
      showStatus(approve ? "Customer profile read approved for 5 minutes. Ask the MCP agent to retry." : "Profile read request rejected.", approve ? CC.success : CC.warning);
      await refreshMcpPrivacy();
    } catch (error) {
      showStatus(error.message || "Could not decide profile request", CC.danger);
      button.disabled = false;
    }
  });
}
async function loadProfilesHttps(data) {
  const creds = data || await chrome.storage.local.get(["accessToken", "backendUrl"]);
  if (!creds.accessToken || !creds.backendUrl) {
    showLoginEmpty("Sign in required", "Open CyberControl Hub and sign in as the cafe account, then reopen this panel.");
    return;
  }
  profilesEl.innerHTML = '<div class="empty"><div class="empty-title">Loading customers\u2026</div>Getting your cafe list ready.</div>';
  if (listCountEl) listCountEl.textContent = "";
  if (listHintEl) listHintEl.textContent = "";
  let profiles = null;
  let transport = "wss";
  try {
    const wssResp = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve({ ok: false, error: "wss_profiles_timeout" }), 12e3);
      chrome.runtime.sendMessage({ type: "WSS_PROFILES_LIST" }, (resp) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
        else resolve(resp || { ok: false, error: "no_response" });
      });
    });
    if ((wssResp == null ? void 0 : wssResp.ok) && Array.isArray(wssResp.profiles)) {
      profiles = wssResp.profiles;
      transport = "wss";
    } else {
      throw new Error((wssResp == null ? void 0 : wssResp.error) || "wss_profiles_failed");
    }
  } catch (e) {
    console.warn("[CC] WSS profiles failed, HTTPS fallback:", e.message);
    transport = "https-fallback";
    profilesEl.innerHTML = '<div class="empty"><div class="empty-title">Still loading\u2026</div>Connection busy \u2014 trying another path.</div>';
    try {
      const r = await fetch(String(creds.backendUrl).replace(/\/$/, "") + "/profiles", {
        headers: { Authorization: "Bearer " + creds.accessToken }
      });
      const text = await r.text();
      let body;
      try {
        body = text ? JSON.parse(text) : [];
      } catch (e2) {
        throw new Error("Bad JSON from /profiles (HTTP " + r.status + ")");
      }
      if (!r.ok) throw new Error(body && body.error || "HTTP " + r.status);
      profiles = Array.isArray(body) ? body : body && body.profiles || [];
    } catch (e2) {
      console.error("[CC] loadProfiles", e2);
      profilesEl.innerHTML = `<div class="empty"><div class="empty-title">Couldn\u2019t load customers</div>Check your connection, then retry.<br><span class="pt-muted" style="font-size:11px">${escapeHtml(e2.message)}</span><br><button type="button" id="retry-profiles">Retry</button></div>`;
      const btn = document.getElementById("retry-profiles");
      if (btn) btn.onclick = () => loadProfilesHttps();
      return;
    }
  }
  allProfiles = profiles || [];
  for (const p of allProfiles) {
    if (profileHasDetailFields(p)) _profileCache.set(p.id, p);
  }
  const sess = await chrome.storage.session.get("_cc_selected");
  if (sess._cc_selected) {
    selectedProfile = allProfiles.find((p) => p.id === sess._cc_selected) || null;
    fillBtn.disabled = !selectedProfile;
    applyAgentVisibility();
  }
  updateFillHint();
  if (!allProfiles.length) {
    profilesEl.innerHTML = `<div class="empty"><div class="empty-title">No customers yet</div>Open Hub, add customers for this cafe, then tap Retry.<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button type="button" id="retry-profiles">Retry</button><button type="button" class="primary" id="open-hub-customers">Open Hub</button></div></div>`;
    const btn = document.getElementById("retry-profiles");
    if (btn) btn.onclick = () => loadProfilesHttps();
    const hubBtn = document.getElementById("open-hub-customers");
    if (hubBtn) hubBtn.onclick = () => openHub(HUB_APP_PATH);
    return;
  }
  renderProfiles("");
  searchEl.focus();
  console.log("[CC] profiles loaded via", transport, allProfiles.length);
}
searchEl.addEventListener("input", () => {
  focusIdx = -1;
  updateSearchClear();
  renderProfiles(searchEl.value);
});
const undoBtn = document.getElementById("undo-btn");
const REQUIRED_FIELDS = ["name", "father_name", "dob", "gender", "aadhaar_number", "address", "state", "pincode"];
function getCompleteness(profile) {
  const data = (profile == null ? void 0 : profile.data) || profile || {};
  let filled = 0;
  const missing = [];
  for (const key of REQUIRED_FIELDS) {
    const val = data[key];
    const v = val && typeof val === "object" ? val.value : val;
    if (v) filled++;
    else missing.push(key.replace(/_/g, " "));
  }
  return { percent: Math.round(filled / REQUIRED_FIELDS.length * 100), missing };
}
const PROFILE_DETAIL_SECTIONS = [
  {
    id: "personal",
    title: "Personal",
    fields: [
      ["name", "Full name", true],
      ["first_name", "First name"],
      ["middle_name", "Middle name"],
      ["last_name", "Last name"],
      ["father_name", "Father's name", true],
      ["mother_name", "Mother's name"],
      ["husband_name", "Husband's name"],
      ["dob", "Date of birth", true],
      ["gender", "Gender", true],
      ["marital_status", "Marital status"],
      ["nationality", "Nationality"],
      ["category", "Category"],
      ["religion", "Religion"]
    ]
  },
  {
    id: "identity",
    title: "Identity",
    fields: [
      ["aadhaar_number", "Aadhaar", true],
      ["ayushman_id", "Ayushman / ABHA"],
      ["name_devanagari", "Name (Hindi)"],
      ["pan_number", "PAN"],
      ["voter_id", "Voter ID"],
      ["driving_license", "Driving license"]
    ]
  },
  {
    id: "contact",
    title: "Contact & address",
    fields: [
      ["phone", "Mobile"],
      ["email", "Email"],
      ["address", "Address", true],
      ["permanent_address", "Permanent address"],
      ["village", "Village"],
      ["block", "Block"],
      ["sub_division", "Sub-division"],
      ["post_office", "Post office"],
      ["police_station", "Police station"],
      ["ward_no", "Ward"],
      ["city", "City"],
      ["district", "District"],
      ["state", "State", true],
      ["pincode", "PIN code", true]
    ]
  },
  {
    id: "education_10th",
    title: "10th",
    fields: [
      ["board_10th", "Board"],
      ["roll_number_10th", "Roll number"],
      ["passing_year_10th", "Year"],
      ["percentage_10th", "Percentage"],
      ["school_name", "School"]
    ]
  },
  {
    id: "education_12th",
    title: "12th",
    fields: [
      ["board_12th", "Board"],
      ["roll_number_12th", "Roll number"],
      ["stream_12th", "Stream"],
      ["passing_year_12th", "Year"],
      ["percentage_12th", "Percentage"]
    ]
  },
  {
    id: "education_grad",
    title: "Graduation",
    fields: [
      ["university_name", "University"],
      ["degree", "Degree"],
      ["passing_year_grad", "Year"],
      ["percentage_grad", "Percentage"]
    ]
  },
  {
    id: "bank",
    title: "Bank",
    fields: [
      ["account_holder_name", "Account holder"],
      ["bank_account_number", "Account number"],
      ["ifsc_code", "IFSC"],
      ["bank_name", "Bank"],
      ["branch_name", "Branch"]
    ]
  },
  {
    id: "travel",
    title: "Travel",
    fields: [
      ["departure", "From"],
      ["arrival", "To"],
      ["journey_date", "Journey date"],
      ["travel_class", "Class"],
      ["quota", "Quota"]
    ]
  }
];
const PROFILE_DETAIL_META = /* @__PURE__ */ new Set([
  "id",
  "displayLabel",
  "displayName",
  "relationship",
  "createdAt",
  "updatedAt",
  "workspaceId",
  "createdBy",
  "updatedBy",
  "documentId",
  "confirmedAt",
  "confirmedBy",
  "source",
  "confidence",
  "document_type",
  "document_label",
  "needs_type",
  "data"
]);
function flattenProfileFields(profile) {
  const out = {};
  const raw = { ...profile || {}, ...profile && profile.data || {} };
  for (const [k, v] of Object.entries(raw)) {
    if (PROFILE_DETAIL_META.has(k)) continue;
    let val = v && typeof v === "object" && v !== null && "value" in v ? v.value : v;
    if (val == null || val === "") continue;
    if (typeof val === "object") {
      try {
        val = Object.entries(val).map(([sk, sv]) => `${sk}: ${sv == null ? "" : String(sv)}`).join(", ");
      } catch (e) {
        continue;
      }
    }
    const text = String(val).trim();
    if (!text) continue;
    out[k] = text;
    const underscored = k.replace(/-/g, "_");
    if (underscored !== k && !out[underscored]) out[underscored] = text;
  }
  if ((profile == null ? void 0 : profile.name) && !out.name) out.name = String(profile.name);
  const phone = getPhone(profile);
  if (phone && !out.phone) out.phone = phone;
  return out;
}
function closeProfileDetail() {
  _detailOpenId = null;
  document.body.classList.remove("showing-detail");
  syncPaneTabs();
  updateFillHint();
}
function stopFileThumbs() {
  if (_thumbObserver) {
    try {
      _thumbObserver.disconnect();
    } catch (e) {
    }
    _thumbObserver = null;
  }
  _thumbWait.length = 0;
}
function revokeFileThumbs() {
  stopFileThumbs();
  _thumbQueued.clear();
  for (const url of _thumbUrls.values()) {
    try {
      URL.revokeObjectURL(url);
    } catch (e) {
    }
  }
  _thumbUrls.clear();
}
function sniffFileKind(bytes, fallback) {
  if (bytes && bytes.length >= 4) {
    if (bytes[0] === 37 && bytes[1] === 80 && bytes[2] === 68 && bytes[3] === 70) return "pdf";
    if (bytes[0] === 255 && bytes[1] === 216) return "image";
    if (bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) return "image";
    if (bytes[0] === 71 && bytes[1] === 73 && bytes[2] === 70) return "image";
    if (bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70) return "image";
  }
  return fallback || "image";
}
function blobFromCanvas(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error("thumb_blob"));
    }, "image/jpeg", 0.72);
  });
}
async function rasterImageThumb(blob) {
  const bmp = await createImageBitmap(blob);
  try {
    const scale = Math.min(THUMB_MAX_PX / bmp.width, THUMB_MAX_PX / bmp.height, 1);
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("no_canvas");
    ctx.drawImage(bmp, 0, 0, w, h);
    const out = await blobFromCanvas(canvas);
    return URL.createObjectURL(out);
  } finally {
    try {
      bmp.close();
    } catch (e) {
    }
  }
}
async function loadPdfjs() {
  if (_pdfjsMod) return _pdfjsMod;
  const mod = await import(chrome.runtime.getURL("vendor/pdfjs/pdf.min.mjs"));
  mod.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("vendor/pdfjs/pdf.worker.min.mjs");
  _pdfjsMod = mod;
  return mod;
}
async function rasterPdfThumb(data) {
  const pdfjs = await loadPdfjs();
  const pdf = await pdfjs.getDocument({
    data,
    isEvalSupported: false,
    useSystemFonts: true,
    verbosity: 0
  }).promise;
  try {
    const page = await pdf.getPage(1);
    const viewport = page.getViewport({ scale: 0.4 });
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(viewport.width));
    canvas.height = Math.max(1, Math.round(viewport.height));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("no_canvas");
    await page.render({ canvasContext: ctx, viewport, canvas }).promise;
    const out = await blobFromCanvas(canvas);
    return URL.createObjectURL(out);
  } finally {
    try {
      await pdf.destroy();
    } catch (e) {
    }
  }
}
globalThis.CcFileThumbs = {
  sniffKind: sniffFileKind,
  rasterImage: rasterImageThumb,
  rasterPdf: rasterPdfThumb
};
function fileKindOfRow(row) {
  let mime = String((row == null ? void 0 : row.mimeType) || "").toLowerCase();
  if (mime === "image/jpg") mime = "image/jpeg";
  const name = String((row == null ? void 0 : row.fileName) || "").toLowerCase();
  if (FILE_MIME[mime]) return { kind: FILE_MIME[mime], mimeType: mime };
  if (/\.pdf$/.test(name)) return { kind: "pdf", mimeType: "application/pdf" };
  if (/\.jpe?g$/.test(name)) return { kind: "image", mimeType: "image/jpeg" };
  if (/\.png$/.test(name)) return { kind: "image", mimeType: "image/png" };
  if (/\.webp$/.test(name)) return { kind: "image", mimeType: "image/webp" };
  if (/\.gif$/.test(name)) return { kind: "image", mimeType: "image/gif" };
  return null;
}
function groupDriveFiles(files) {
  const buckets = /* @__PURE__ */ new Map();
  for (const tag of FILE_TAGS) buckets.set(tag, []);
  buckets.set("Other", []);
  for (const file of files) {
    const tag = FILE_TAGS.includes(file.tag) ? file.tag : "Other";
    buckets.get(tag).push(file);
  }
  const out = [];
  for (const [title, items] of buckets) {
    if (items.length) out.push({ title, items });
  }
  return out;
}
function closeProfileFiles() {
  _filesOpenId = null;
  _armedFileId = null;
  document.body.classList.remove("showing-files");
  try {
    chrome.runtime.sendMessage({ type: "cc_file_drag_end" }, () => void chrome.runtime.lastError);
  } catch (e) {
  }
  syncPaneTabs();
  updateFillHint();
}
function paintFilesHeader(profile, count) {
  paintPaneHeader(profile, String(count), count > 0 ? "ok" : "warn");
}
function renderFilesList(files) {
  if (!filesBodyEl) return;
  if (!files.length) {
    filesBodyEl.innerHTML = `<div class="detail-empty">No images or PDFs for this customer.</div>`;
    return;
  }
  const groups = groupDriveFiles(files);
  filesBodyEl.innerHTML = groups.map(
    (group) => `<div class="detail-section"><div class="detail-section-title">${escapeHtml(group.title)}</div><div class="file-grid">` + group.items.map((file) => {
      const label = escapeHtml(file.fileName || "file");
      const kind = file.kind === "pdf" ? "PDF" : file.tag || "Image";
      const armed = _armedFileId === file.id ? " armed" : "";
      const thumb = _thumbUrls.has(file.id) ? `<img alt="" src="${escapeHtml(_thumbUrls.get(file.id))}">` : file.kind === "pdf" ? "PDF" : "IMG";
      return `<button type="button" class="file-tile${armed}" draggable="true" data-file-id="${escapeHtml(file.id)}" title="Drag onto a file box, or click then click the box"><div class="file-thumb" data-thumb-id="${escapeHtml(file.id)}">${thumb}</div><div class="file-name">${label}</div><div class="file-kind">${escapeHtml(kind)}</div></button>`;
    }).join("") + `</div></div>`
  ).join("");
  bindFileTiles(files);
  observeFileThumbs(files);
}
function bindFileTiles(files) {
  if (!filesBodyEl) return;
  const byId = /* @__PURE__ */ new Map();
  for (const f of files) byId.set(f.id, f);
  filesBodyEl.querySelectorAll(".file-tile").forEach((tile) => {
    const file = byId.get(tile.getAttribute("data-file-id"));
    if (!file) return;
    tile.addEventListener("dragstart", (e) => {
      try {
        e.dataTransfer.setData("text/plain", file.id);
        e.dataTransfer.effectAllowed = "copy";
      } catch (e2) {
      }
      _armedFileId = file.id;
      tile.classList.add("armed");
      armFileOnPage(file, false);
    });
    tile.addEventListener("dragend", () => {
      _armedFileId = null;
      tile.classList.remove("armed");
      try {
        chrome.runtime.sendMessage({ type: "cc_file_drag_end" }, () => void chrome.runtime.lastError);
      } catch (e) {
      }
    });
    tile.addEventListener("click", (e) => {
      e.preventDefault();
      _armedFileId = file.id;
      filesBodyEl.querySelectorAll(".file-tile.armed").forEach((el) => el.classList.remove("armed"));
      tile.classList.add("armed");
      armFileOnPage(file, true);
    });
  });
}
function armFileOnPage(file, autoPlace) {
  showStatus(autoPlace ? "Click a highlighted Choose File / Upload control" : "Drop on a highlighted Choose File / Upload control", CC.info);
  void getActivePageTab().then((tab) => {
    chrome.runtime.sendMessage({
      type: "cc_file_drag_start",
      tabId: tab && tab.id,
      fileId: file.id,
      fileName: file.fileName,
      mimeType: file.mimeType,
      autoPlace: !!autoPlace
    }, (r) => {
      if (chrome.runtime.lastError) return;
      if (!r || r.ok) return;
      if (r.error === "open_a_form_page") showStatus("Open a form page to place this file", CC.danger);
      else if (r.error === "no_tab") showStatus("Open a form page first", CC.danger);
      else showStatus(r.error || "Could not arm drop", CC.danger);
    });
  });
}
function observeFileThumbs(files) {
  stopFileThumbs();
  if (!filesBodyEl || !files.length) return;
  const byId = /* @__PURE__ */ new Map();
  for (const f of files) byId.set(f.id, f);
  const pending = [];
  filesBodyEl.querySelectorAll("[data-thumb-id]").forEach((host) => {
    const file = byId.get(host.getAttribute("data-thumb-id"));
    if (!file || _thumbUrls.has(file.id)) return;
    host.classList.add("is-loading");
    pending.push(file);
  });
  if (!pending.length) return;
  _thumbObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const id = entry.target.getAttribute("data-thumb-id");
      _thumbObserver.unobserve(entry.target);
      enqueueFileThumb(byId.get(id));
    }
  }, { root: filesBodyEl, rootMargin: "120px", threshold: 0.01 });
  filesBodyEl.querySelectorAll("[data-thumb-id]").forEach((host) => {
    if (_thumbUrls.has(host.getAttribute("data-thumb-id"))) return;
    _thumbObserver.observe(host);
  });
}
function enqueueFileThumb(file) {
  if (!file || _thumbUrls.has(file.id) || _thumbQueued.has(file.id)) return;
  _thumbQueued.add(file.id);
  _thumbWait.push(file);
  void pumpFileThumbs();
}
async function pumpFileThumbs() {
  while (_thumbInflight < THUMB_CONCURRENCY && _thumbWait.length) {
    const file = _thumbWait.shift();
    _thumbInflight += 1;
    void loadOneFileThumb(file).finally(() => {
      _thumbInflight -= 1;
      void pumpFileThumbs();
    });
  }
}
function paintThumbHost(fileId, url) {
  if (!filesBodyEl || !url) return;
  const sel = '[data-thumb-id="' + (typeof CSS !== "undefined" && CSS.escape ? CSS.escape(fileId) : String(fileId)) + '"]';
  const host = filesBodyEl.querySelector(sel);
  if (!host) return;
  host.classList.remove("is-loading");
  host.innerHTML = "";
  const img = document.createElement("img");
  img.alt = "";
  img.src = url;
  host.appendChild(img);
}
async function loadOneFileThumb(file) {
  const gen = _filesLoadGen;
  if (!file || _filesOpenId == null) return;
  const fail = () => {
    _thumbQueued.delete(file.id);
    const sel = '[data-thumb-id="' + (typeof CSS !== "undefined" && CSS.escape ? CSS.escape(file.id) : String(file.id)) + '"]';
    const host = filesBodyEl && filesBodyEl.querySelector(sel);
    if (host) host.classList.remove("is-loading");
  };
  try {
    const data = await chrome.storage.local.get(["backendUrl", "accessToken"]);
    if (!data.accessToken || !data.backendUrl) {
      fail();
      return;
    }
    if (gen !== _filesLoadGen || _filesOpenId == null) return;
    const base = String(data.backendUrl).replace(/\/$/, "");
    const res = await fetch(base + "/drive/download/" + encodeURIComponent(file.id), {
      headers: { Authorization: "Bearer " + data.accessToken }
    });
    if (!res.ok) {
      fail();
      return;
    }
    const buf = await res.arrayBuffer();
    if (gen !== _filesLoadGen || _filesOpenId == null) return;
    if (!buf || !buf.byteLength) {
      fail();
      return;
    }
    const bytes = new Uint8Array(buf);
    const kind = sniffFileKind(bytes, file.kind);
    let url = "";
    if (kind === "pdf") {
      url = await rasterPdfThumb(bytes);
    } else {
      const mime = file.mimeType && String(file.mimeType).indexOf("image/") === 0 ? file.mimeType : "image/jpeg";
      try {
        url = await rasterImageThumb(new Blob([bytes], { type: mime }));
      } catch (e) {
        url = URL.createObjectURL(new Blob([bytes], { type: mime }));
      }
    }
    if (gen !== _filesLoadGen) {
      try {
        URL.revokeObjectURL(url);
      } catch (e) {
      }
      return;
    }
    const prev = _thumbUrls.get(file.id);
    if (prev) URL.revokeObjectURL(prev);
    _thumbUrls.set(file.id, url);
    paintThumbHost(file.id, url);
  } catch (e) {
    fail();
  }
}
async function loadAndRenderFiles(profile) {
  const id = profile == null ? void 0 : profile.id;
  if (!id || !filesBodyEl) return;
  const phone = getPhone(profile);
  paintFilesHeader(profile, (_filesCache.get(id) || []).length);
  if (!phone) {
    filesBodyEl.innerHTML = `<div class="detail-empty">No phone on file \u2014 files are stored by phone number.</div>`;
    paintPaneHeader(profile, "0", "warn");
    return;
  }
  const cached = _filesCache.get(id);
  if (cached) renderFilesList(cached);
  else filesBodyEl.innerHTML = `<div class="detail-empty">Loading files\u2026</div>`;
  const gen = ++_filesLoadGen;
  try {
    const data = await chrome.storage.local.get(["backendUrl", "accessToken"]);
    if (!data.accessToken || !data.backendUrl) {
      if (gen === _filesLoadGen) {
        filesBodyEl.innerHTML = `<div class="detail-empty">Sign in to Hub to see this folder.</div>`;
      }
      return;
    }
    const url = String(data.backendUrl).replace(/\/$/, "") + "/drive/files/ws?customerId=" + encodeURIComponent(phone);
    const res = await fetch(url, { headers: { Authorization: "Bearer " + data.accessToken } });
    if (!res.ok) throw new Error("files_fetch_" + res.status);
    const rows = await res.json();
    const files = [];
    const list = Array.isArray(rows) ? rows : [];
    for (const row of list) {
      if (!row || !row.id) continue;
      const typed = fileKindOfRow(row);
      if (!typed) continue;
      files.push({
        id: String(row.id).slice(0, 80),
        fileName: String(row.fileName || "file").slice(0, 80),
        tag: row.tag ? String(row.tag).slice(0, 40) : "",
        kind: typed.kind,
        mimeType: typed.mimeType
      });
      if (files.length >= 200) break;
    }
    _filesCache.set(id, files);
    if (gen !== _filesLoadGen || _filesOpenId !== id) return;
    paintFilesHeader(profile, files.length);
    renderFilesList(files);
  } catch (e) {
    if (gen !== _filesLoadGen || _filesOpenId !== id) return;
    if (!cached) filesBodyEl.innerHTML = `<div class="detail-empty">Could not load this folder.</div>`;
  }
}
function openProfileFiles(id) {
  if (!id) return;
  _detailOpenId = null;
  _filesOpenId = id;
  document.body.classList.remove("showing-detail");
  document.body.classList.add("showing-files");
  syncPaneTabs();
  const listRow = allProfiles.find((p) => p.id === id) || selectedProfile;
  const cached = _profileCache.get(id) || ((_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === id ? _prefetchedProfile : null);
  const profile = cached || listRow || { id, name: "Customer" };
  if ((selectedProfile == null ? void 0 : selectedProfile.id) !== id) selectProfile(id, { skipRender: true });
  else updateFillHint();
  void loadAndRenderFiles(profile);
}
async function openSelectedFolderInHub() {
  const profile = (_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === (selectedProfile == null ? void 0 : selectedProfile.id) ? _prefetchedProfile : selectedProfile;
  const phone = getPhone(profile || {});
  if (phone) {
    await openHub("/app/files?phone=" + encodeURIComponent(phone));
    return;
  }
  await openHub("/app/files");
}
function renderProfileDetail(profile) {
  if (!customerPaneEl || !detailBodyEl) return;
  const { percent } = getCompleteness(profile);
  const cls = percent >= 85 ? "ok" : percent >= 50 ? "warn" : "low";
  paintPaneHeader(profile, percent + "%", cls);
  const flat = flattenProfileFields(profile);
  const claimed = /* @__PURE__ */ new Set();
  const chunks = [];
  for (const section of PROFILE_DETAIL_SECTIONS) {
    const rows = [];
    for (const field of section.fields) {
      const key = field[0];
      const label = field[1];
      const required = !!field[2];
      const value = flat[key] || "";
      if (!value && !required) continue;
      claimed.add(key);
      rows.push(
        `<div class="detail-row"><div class="detail-label">${escapeHtml(label)}</div>` + (value ? `<div class="detail-value">${escapeHtml(value)}</div>` : `<div class="detail-value missing">Missing</div>`) + `</div>`
      );
    }
    if (!rows.length) continue;
    chunks.push(
      `<div class="detail-section"><div class="detail-section-title">${escapeHtml(section.title)}</div>` + rows.join("") + `</div>`
    );
  }
  const extras = Object.keys(flat).filter((k) => !claimed.has(k) && flat[k]);
  if (extras.length) {
    chunks.push(
      `<div class="detail-section"><div class="detail-section-title">Other</div>` + extras.map(
        (k) => `<div class="detail-row"><div class="detail-label">${escapeHtml(k.replace(/_/g, " "))}</div><div class="detail-value">${escapeHtml(flat[k])}</div></div>`
      ).join("") + `</div>`
    );
  }
  detailBodyEl.innerHTML = chunks.length ? chunks.join("") : `<div class="detail-empty">No stored fields yet. Complete this profile in Hub.</div>`;
}
function openProfileDetail(id) {
  if (!id) return;
  if (_filesOpenId) {
    _filesOpenId = null;
    _armedFileId = null;
    try {
      chrome.runtime.sendMessage({ type: "cc_file_drag_end" }, () => void chrome.runtime.lastError);
    } catch (e) {
    }
  }
  _detailOpenId = id;
  document.body.classList.remove("showing-files");
  document.body.classList.add("showing-detail");
  syncPaneTabs();
  const listRow = allProfiles.find((p) => p.id === id) || selectedProfile;
  const cached = _profileCache.get(id) || ((_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === id ? _prefetchedProfile : null);
  const profile = cached || listRow || { id, name: "Customer" };
  renderProfileDetail(profile);
  if ((selectedProfile == null ? void 0 : selectedProfile.id) !== id) selectProfile(id, { skipRender: true });
  else updateFillHint();
  if (!profileHasDetailFields(profile)) void prefetchProfile(id);
}
async function openSelectedInHub() {
  const profile = (_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === (selectedProfile == null ? void 0 : selectedProfile.id) ? _prefetchedProfile : selectedProfile;
  const phone = getPhone(profile || {});
  if (phone) {
    await openHub("/app/customers/" + encodeURIComponent(phone));
    return;
  }
  await openHub("/app/customers");
}
updateSearchClear();
updateFillHint();
fillBtn.addEventListener("click", async () => {
  var _a2;
  if (!selectedProfile) return;
  closeCustomerPane();
  const full = (_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === selectedProfile.id ? _prefetchedProfile : selectedProfile;
  const { percent, missing } = getCompleteness(full);
  if (percent < 100 && missing.length > 0) {
    const warn = document.getElementById("completeness-warn");
    warn.innerHTML = `<span>\u26A0\uFE0F ${percent}% complete \u2014 will skip: ${missing.slice(0, 3).join(", ")}${missing.length > 3 ? "..." : ""}</span><button type="button" id="fill-anyway">Fill anyway</button><button type="button" id="fill-cancel" class="warn-cancel">Not now</button>`;
    warn.style.display = "flex";
    const cancelled = await new Promise((resolve) => {
      _completenessResolve = resolve;
      const anyway = document.getElementById("fill-anyway");
      const cancel = document.getElementById("fill-cancel");
      if (anyway) anyway.onclick = () => hideCompletenessWarn(false);
      if (cancel) cancel.onclick = () => hideCompletenessWarn(true);
    });
    if (cancelled) return;
  }
  fillBtn.disabled = true;
  fillBtn.innerHTML = "<span>Filling\u2026</span>";
  resultsEl.style.display = "none";
  undoBtn.style.display = "none";
  showProgress("Preparing\u2026");
  saveRecent(selectedProfile.id);
  try {
    const tab = await getActivePageTab();
    if (!(tab == null ? void 0 : tab.id)) {
      showStatus("No active tab", CC.danger);
      hideProgress();
      return;
    }
    if (!tab.url || tab.url.startsWith("chrome") || tab.url.startsWith("edge://")) {
      showStatus("Open a form page first", CC.danger);
      hideProgress();
      return;
    }
    if (tab.url.startsWith("file:")) {
      showStatus("File pages cannot be filled", CC.danger);
      hideProgress();
      return;
    }
    _lastFillTabId = tab.id;
    try {
      _lastFillHost = new URL(tab.url).hostname.replace(/^www\./, "");
    } catch (e) {
      _lastFillHost = null;
    }
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const snapshot = {};
        document.querySelectorAll("input, select, textarea").forEach((el, idx) => {
          const key = el.id || el.name || el.getAttribute("formcontrolname") || `anon_${idx}`;
          let selector = "";
          if (el.id) selector = `#${CSS.escape(el.id)}`;
          else if (el.name) selector = `[name="${CSS.escape(el.name)}"]`;
          else if (el.getAttribute("formcontrolname")) {
            selector = `[formcontrolname="${CSS.escape(el.getAttribute("formcontrolname"))}"]`;
          }
          snapshot[key] = { value: el.value, type: el.type, selector };
        });
        window.__ccUndoSnapshot = snapshot;
      }
    });
    const data = await chrome.storage.local.get(["backendUrl", "accessToken"]);
    let fullProfile = (_prefetchedProfile == null ? void 0 : _prefetchedProfile.id) === selectedProfile.id ? _prefetchedProfile : selectedProfile;
    if (fullProfile === selectedProfile) {
      try {
        const fr = await fetch(data.backendUrl + "/profiles/" + selectedProfile.id, {
          headers: { Authorization: "Bearer " + data.accessToken }
        });
        if (fr.ok) fullProfile = await fr.json();
      } catch (e) {
        console.warn("[CC] full profile fetch failed:", e.message);
      }
    }
    selectedProfile = fullProfile;
    if (!((_a2 = globalThis.CcFillOrchestrator) == null ? void 0 : _a2.runProductFill)) {
      showStatus("Fill orchestrator not loaded", CC.danger);
      hideProgress();
      return;
    }
    const fillOut = await globalThis.CcFillOrchestrator.runProductFill({
      tabId: tab.id,
      profile: selectedProfile,
      backendUrl: data.backendUrl,
      accessToken: data.accessToken,
      runtimeVersion: VERSION,
      executionPreference: "AUTO",
      onProgress: (text, pct) => updateProgress(text, pct)
    });
    const filled = fillOut.filled || 0;
    const failed = fillOut.failed || 0;
    const skipped = fillOut.skipped || 0;
    const records = fillOut.records || [];
    window._lastFilledRecords = records.filter((r) => r.result === "filled");
    showResults(filled, skipped, failed, records.filter((r) => r.result !== "filled"));
    undoBtn.style.display = filled > 0 ? "flex" : "none";
    const statusColor = !fillOut.ok || failed ? CC.danger : fillOut.observationError ? CC.danger : CC.success;
    const errApi = globalThis.CcRuntimeErrors;
    let statusMsg = fillOut.operatorMessage || ((errApi == null ? void 0 : errApi.operatorMessageFor) ? errApi.operatorMessageFor(fillOut.error, null) : fillOut.error || "Fill finished");
    if (errApi == null ? void 0 : errApi.sanitizeOperatorDetail) {
      const sanitized = errApi.sanitizeOperatorDetail(statusMsg);
      if (sanitized) statusMsg = fillOut.operatorMessage || sanitized;
    }
    showStatus(statusMsg, statusColor);
  } catch (e) {
    const errApi = globalThis.CcRuntimeErrors;
    const msg = (errApi == null ? void 0 : errApi.operatorMessageFor) ? errApi.operatorMessageFor("gateway_error", null) : "Something went wrong while filling.";
    showStatus(msg, CC.danger);
  } finally {
    fillBtn.innerHTML = FILL_BTN_LABEL;
    updateFillHint();
    hideProgress();
  }
});
undoBtn.addEventListener("click", async () => {
  if (!_lastFillTabId) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: _lastFillTabId },
      func: () => {
        const snapshot = window.__ccUndoSnapshot || {};
        for (const [key, info] of Object.entries(snapshot)) {
          const el = document.querySelector(info.selector);
          if (el) {
            el.value = info.value;
            el.dispatchEvent(new Event("input", { bubbles: true }));
            el.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
      }
    });
    undoBtn.style.display = "none";
    resultsEl.style.display = "none";
    showStatus("\u21A9 Fill undone", CC.success);
  } catch (e) {
    showStatus("Undo failed: " + e.message, CC.danger);
  }
});
document.getElementById("open-btn").addEventListener("click", () => {
  openHub(HUB_APP_PATH);
});
if (hubHeadBtn) {
  hubHeadBtn.addEventListener("click", () => {
    openHub(HUB_APP_PATH);
  });
}
if (detailBtn) {
  detailBtn.addEventListener("click", () => {
    if (!selectedProfile) return;
    if (_detailOpenId === selectedProfile.id) closeCustomerPane();
    else openProfileDetail(selectedProfile.id);
  });
}
if (filesBtn) {
  filesBtn.addEventListener("click", () => {
    if (!selectedProfile) return;
    if (_filesOpenId === selectedProfile.id) closeCustomerPane();
    else openProfileFiles(selectedProfile.id);
  });
}
if (paneBackBtn) {
  paneBackBtn.addEventListener("click", () => closeCustomerPane());
}
if (paneHubBtn) {
  paneHubBtn.addEventListener("click", () => {
    if (_filesOpenId) void openSelectedFolderInHub();
    else void openSelectedInHub();
  });
}
if (tabDetailBtn) {
  tabDetailBtn.addEventListener("click", () => {
    const id = _detailOpenId || _filesOpenId || (selectedProfile == null ? void 0 : selectedProfile.id);
    if (id) openProfileDetail(id);
  });
}
if (tabFilesBtn) {
  tabFilesBtn.addEventListener("click", () => {
    const id = _filesOpenId || _detailOpenId || (selectedProfile == null ? void 0 : selectedProfile.id);
    if (id) openProfileFiles(id);
  });
}
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (_filesOpenId || _detailOpenId) {
    e.preventDefault();
    closeCustomerPane();
  }
});
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== "cc_file_placed") return;
  if (msg.ok) {
    _armedFileId = null;
    if (filesBodyEl) filesBodyEl.querySelectorAll(".file-tile.armed").forEach((el) => el.classList.remove("armed"));
    showStatus("Placed " + (msg.fileName || "file"), CC.success);
  } else if (msg.error === "open_a_form_page") {
    showStatus("Open a form page to place this file", CC.danger);
  } else if (msg.error) {
    showStatus(msg.error, CC.danger);
  }
});
let _pendingPlan = null;
function cafeFillOnlyMessage() {
  showStatus("Use Fill this form. Remote action lists are not executed.", CC.warning);
}
if (agentBtn) {
  agentBtn.addEventListener("click", () => cafeFillOnlyMessage());
}
if (agentExecuteBtn) {
  agentExecuteBtn.addEventListener("click", () => cafeFillOnlyMessage());
}
if (agentCancelBtn) {
  agentCancelBtn.addEventListener("click", () => {
    if (agentPanel) agentPanel.style.display = "none";
    _pendingPlan = null;
  });
}
init();
